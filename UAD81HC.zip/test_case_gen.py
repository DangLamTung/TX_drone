import xlrd 
import re
# Give the location of the file 
loc = ("CSWTest_ABS10MB_SYM_FZK_BL01_DiagCAN.xls") 


wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_name('C) CSW-Basic Customer Specials') 

print(sheet.row_values(19)[6]) 
exp_command = sheet.row_values(19)[7].split("\n")


temp = (sheet.row_values(19)[5]).replace(" ","_")
print(temp)
Data = "[RB_UNIVERSAL_01J." + temp +"]" +"\n"
Data += "purpose                   = " + sheet.row_values(19)[5] + "\n"
Data += "test_sequence             = @("


send_mode = ""
send_id = 0

temp_command_1 = (sheet.row_values(19)[6]).split("\n")
main_command = []
command_data = ""
diag_request = "Diag_Request              = @("
exp_request = "Exp_Response              = @("
init_request = "init_diag_sequences		= @('Initial.seq')"

data_to_send = []
for i in temp_command_1:
    
    print(i[0]) 
    if(i[0].isnumeric()):
         
        temp_command = i.split(",")
        for j in temp_command:
            if j.lower().find('send') != -1:
                
                if(send_mode == "diag"):
                    command_data += "'send_request','wait_500',"
                    print(re.findall("[0-9A-E][0-9A-E]", j))
                    temp = ""
                    for (count, data) in enumerate(re.findall("[0-9A-E][0-9A-E]", i[1:])): 
                        if( count != len(re.findall("[0-9A-E][0-9A-E]", i[1:])) - 1):
                            temp += str(data) + " "
                        else:
                            temp += str(data) 
                    data_to_send.append(temp)

                else:
                    command_data += "'writeEEPROM'" + "," + "'wait_1000,'"

                    print(re.findall("\d+", j[1:]))
                    temp = ""
                    for (i, data) in enumerate(re.findall("\d+", j)): 
                        if( i!= len(re.findall("\d+", j)) - 1):
                            temp += str(data) + " "
                        else:
                            temp += str(data) 
                    data_to_send.append(temp)
                    

            if j.lower().find('ignition on') != -1:
                command_data += "'trace_start'" + "," + "'ecu_on'"+","+ "'wait_2000'"+","

            if ((j.lower().find('drive the system off to') != -1)):
                # print(re.findall("\d+", j))
                main_command = "run"
                command_data += "'target_speed_" + str(re.findall("\d+", j)[0]) +"," +  "'wait_2000'"+"," +"'target_speed_0',"

            if j.lower().find('wait lamp check time (e.g. 4s)') != -1:
                main_command = "lamp"
                command_data += "'wait_500'" + ","

            
            if j.lower().find('perform a maneuver at') != -1:
                main_command = "run"
                command_data += "'target_speed_" + str(j[j.find('Perform a maneuver at') + len('Perform a maneuver at')  +1]) +"',"
            # if i.find('wait lamp check time (e.g. 4s)') != -1:
            #     command_data += "wait_500" + ","
        if i.lower().find('tk_winx') != -1:
            
            send_mode = "diag"
            main_command = "send"
            if j.lower().find('write') != -1:
                command_data += "'writeEEPROM'" +"," + "'wait_500',"
                print(re.findall("[0-9A-E][0-9A-E]", i[1:]))
            if j.lower().find('customer') != -1:
                command_data += "'start_diag_communication_CU'" +"," + "'wait_500', 'clear_Tk_log',"
            else:
                command_data += "'start_diag_communication_RB'" +","
        
    else:
        temp_command = i.split(",")
        if(main_command == "send"):
            for j in temp_command:
                print(re.findall("\d+", j))
                temp = ""
                for (i, data) in enumerate(re.findall("\d+", j)): 
                    if( i!= len(re.findall("\d+", j)) - 1):
                        temp += str(data) + " "
                    else:
                        temp += str(data) 
                data_to_send.append(temp)
            command_data += "'send_request','wait_500',"
if(main_command == "send"):
    command_data += "'stop_diag_communication_CU'," +"'wait_1000' ," +"'save_Tk_log'," + "'wait_1000',"
command_data += "'trace_stop'" + ",'ecu_off')\n"
Data += command_data

for (i, data) in enumerate(data_to_send):
    if( i!= len(data_to_send) - 1):
        diag_request += "'" + data + "',"
    else:
        diag_request += "'" + data + "'"

diag_request += ")\n"

exp_data = []


for (k,i) in enumerate(exp_command):
    temp = ""

    
    
    count = re.findall("[0-9A-E][0-9A-E]", i)
    for (j, data) in enumerate(count):
        if(j != len(count) - 1):
            temp += data + " "
        else:
            temp += data
        
                
    exp_data.append(temp)
    if(temp != ''):
        if(k!= len(exp_command) - 1):
            exp_request += "'" + temp +"'," 
        else:
            exp_request += "'" + temp +"')\n"


Data += diag_request
Data += exp_request
Data += init_request

print(Data)
print(data_to_send)
print(exp_request)
f = open("C22.par", "a")
f.write(Data)
f.close()